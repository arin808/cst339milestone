package com.gcu.data;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import com.gcu.model.ProductEntity;
import com.gcu.model.ProductModel;

@Service
public class ProductsDataServiceForRepository implements ProductsDataAccessInterface<ProductEntity>
{
	@Autowired
	private ProductsRepository prodRepository;

	public ProductsDataServiceForRepository(ProductsRepository prodRepository)
	{
		this.prodRepository = prodRepository;
	}
	
	@Override
	public List<ProductEntity> getAllProducts()
	{
		List<ProductEntity> products = (List<ProductEntity>) prodRepository.findAll(); 
		return products;
	}

	@Override
	public ProductEntity getByProductId(String id)
	{
		return prodRepository.findById(id).orElse(null);
	}

	@Override
	public List<ProductEntity> searchProductByName(String searchTerm)
	{
		List<ProductEntity> product = prodRepository.findByVacationNameContainingIgnoreCase(searchTerm);
		return product;
	}

	@Override
	public List<ProductEntity> searchProductByLocation(String searchTerm)
	{
		List<ProductEntity> product = prodRepository.findByLocationContainingIgnoreCase(searchTerm);
		return product;
	}

	@Override
	public String addProduct(ProductEntity model)
	{
		ProductEntity result = prodRepository.save(model);
		if(result == null)
		{
			return null;
		}
		return result.getVacationId();
	}

	@Override
	public boolean deleteProduct(String id)
	{
		prodRepository.deleteById(id);
		return true;
	}

	@Override
	public ProductEntity updateProduct(String id, ProductEntity updateProduct)
	{
		ProductEntity product = prodRepository.save(updateProduct);
		return product;
	}

}
