package com.gcu.business;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.gcu.data.UsersDataAccessInterface;
import com.gcu.data.UsersDataServiceForRepository;
import com.gcu.model.LoginModel;
import com.gcu.model.UserEntity;
import com.gcu.model.UserModel;

@Service
public class UsersBusinessService implements UsersBusinessInterface, UserDetailsService
{
	@Autowired
	private UsersDataServiceForRepository service;
	
	public UsersBusinessService(UsersDataServiceForRepository service)
	{
		this.service = service;
	}
	
	@Override
	public void test()
	{
		System.out.println("Test from UsersBusinessService");
	}

	@Override
	public UserModel getById(String id)
	{
		UserEntity result = service.getById(id);
		UserModel user = new UserModel(result.getId(), result.getFirstName(), result.getLastName(),
				result.getEmail(), result.getPhoneNumber(), result.getUsername(), result.getPassword(), result.getRoles());
		return user;
	}

	@Override
	public List<UserModel> getAllUsers()
	{
		//Users entity list
		List<UserEntity> usersE = service.getAllUsers();
		//Translate to user model list
		List<UserModel> users = new ArrayList<UserModel>();
		for(UserEntity entity: usersE)
		{
			users.add(new UserModel(entity.getId(), entity.getFirstName(), entity.getLastName(), 
					entity.getEmail(), entity.getPhoneNumber(), entity.getUsername(), entity.getPassword(), entity.getRoles()));
		}
		return users;
	}

	@Override
	public List<UserModel> searchByUsername(String searchTerm)
	{
		//Users entity list
		List<UserEntity> usersE = service.searchByUsername(searchTerm);
		//Translate to user model list
		List<UserModel> users = new ArrayList<UserModel>();
		for(UserEntity entity: usersE)
		{
			users.add(new UserModel(entity.getId(), entity.getFirstName(), entity.getLastName(), 
					entity.getEmail(), entity.getPhoneNumber(), entity.getUsername(), entity.getPassword(), entity.getRoles()));
		}
		return users;
	}
	
	@Override
	public List<UserModel> searchByFirstName(String searchTerm)
	{
		//Users entity list
		List<UserEntity> usersE = service.searchByFirstName(searchTerm);
		//Translate to user model list
		List<UserModel> users = new ArrayList<UserModel>();
		for(UserEntity entity: usersE)
		{
			users.add(new UserModel(entity.getId(), entity.getFirstName(), entity.getLastName(), 
					entity.getEmail(), entity.getPhoneNumber(), entity.getUsername(), entity.getPassword(), entity.getRoles()));
		}
		return users;
	}

	@Override
	public List<UserModel> searchByLastName(String searchTerm)
	{
		//Users entity list
		List<UserEntity> usersE = service.searchByLastName(searchTerm);
		//Translate to user model list
		List<UserModel> users = new ArrayList<UserModel>();
		for(UserEntity entity: usersE)
		{
			users.add(new UserModel(entity.getId(), entity.getFirstName(), entity.getLastName(), 
					entity.getEmail(), entity.getPhoneNumber(), entity.getUsername(), entity.getPassword(), entity.getRoles()));
		}
		return users;
	}
	
	@Override
	public String addUser(UserModel model)
	{
		ArrayList<String> roles = new ArrayList<String>();
		roles.add("ROLE_USER");
		
		UserEntity entity = new UserEntity(model.getId(), model.getFirstName(), model.getLastName(), 
				model.getEmail(), model.getPhoneNumber(), model.getUsername(), model.getPassword(), roles);
		return service.addUser(entity);
	}

	@Override
	public boolean deleteUser(String id)
	{
		return service.deleteUser(id);
	}

	@Override
	public UserModel updateUser(String id, UserModel updateUser)
	{
		ArrayList<String> roles = new ArrayList<String>();
		roles.add("ROLE_USER"); 
		UserEntity entity = new UserEntity(updateUser.getId(), updateUser.getFirstName(), updateUser.getLastName(),
				updateUser.getEmail(), updateUser.getPhoneNumber(), updateUser.getUsername(), updateUser.getPassword(), roles);
		
		UserEntity result = service.updateUser(id, entity);
		
		UserModel updated = new UserModel(result.getId(), result.getFirstName(), result.getLastName(),
				result.getEmail(), result.getPhoneNumber(), result.getUsername(), result.getPassword(), entity.getRoles());
		return updated;
	}

	@Override
	public void init()
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void destroy()
	{
		// TODO Auto-generated method stub

	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException
	{
		System.out.println("UserBusinessService is searching for " + username);
		//Try to find the user in the db. If not found, throw an exception
		List<UserEntity> users = service.searchByUsername(username);
		UserEntity user = users.get(0);
		System.out.println(user);
		
		if(user != null)
		{
			System.out.println(user);
			List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
			for(String role: user.getRoles()) 
			{
				System.out.println("Role ========= " + role);
				authorities.add(new SimpleGrantedAuthority(role));
			}
			return new User(user.getUsername(), user.getPassword(), authorities);
		}
		else
		{
			System.out.println("User not found");
			throw new UsernameNotFoundException("username not found");
		}
	}
}
