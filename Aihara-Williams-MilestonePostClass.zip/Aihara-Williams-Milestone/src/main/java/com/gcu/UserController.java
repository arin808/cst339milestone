package com.gcu;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gcu.model.LoginModel;
import com.gcu.model.UserModel;

@Controller
@RequestMapping("/")
public class UserController 
{
	
	@GetMapping("/home")
	public String homeDisplay()
	{
		return "home";
	}
	
	@GetMapping("/register")
	public String registerDisplay(Model model)
	{
		//Display register screen
		model.addAttribute("title", "Registration");
		model.addAttribute("userModel", new UserModel());
		return "register";
	}
	
	@PostMapping("/doRegister")
	public String doRegister(@Valid UserModel userModel, BindingResult bindingResult, Model model)
	{
		if(bindingResult.hasErrors())
		{
			model.addAttribute("title", "Registration");
			return "register";
		}
		model.addAttribute("userModel", userModel);
		 
		return "registerSuccess";
	}
	
	@GetMapping("/login")
	public String loginDisplay(Model model)
	{
		//Display Login form
		model.addAttribute("title", "Login Form");
		model.addAttribute("loginModel", new LoginModel());
		return "login";
	}
	@PostMapping("/doLogin")
	public String doLogin(@Valid LoginModel loginModel,  BindingResult bindingResult, Model model)
	{		
		UserModel user1 = new UserModel("Arin", "Aihara", "aaihara@my.gcu.edu", "8082501938", "arin808", "Kaulana"); 
		UserModel user2 = new UserModel("Josh", "Williams", "jwilliams425@my.gcu.edu", "1234567890", "kingjosh", "Frontend");
		
		if(bindingResult.hasErrors())
		{
			model.addAttribute("title", "Login Form");
			return "login";
		}
		
	
		if(loginModel.getUsername().equals(user1.getUsername()) || loginModel.getUsername().equals(user2.getUsername())) 
		{
			if(loginModel.getPassword().equals(user1.getPassword()) || loginModel.getPassword().equals(user2.getPassword()))
			{
				model.addAttribute("loginModel", loginModel); 
				return "loginSuccess"; 
			}
		}
		model.addAttribute("title", "Login Form");
		return "login";
	}
}
