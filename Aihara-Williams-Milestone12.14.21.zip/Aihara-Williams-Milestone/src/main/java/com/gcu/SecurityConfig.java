
package com.gcu;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.gcu.business.UsersBusinessService;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter
{
	@Autowired
	PasswordEncoder passwordEncoder;
	
	@Autowired
	UsersBusinessService service;
	
	@Bean
	BCryptPasswordEncoder passwordEncoder()
	{
		return new BCryptPasswordEncoder();
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception
	{
		http
			.authorizeRequests()
			//most restricted pages first
			.antMatchers("/userAdmin").hasRole("ADMIN")
			.antMatchers("/searchUsers").hasRole("ADMIN")
			.antMatchers("/userSearchFirst").hasRole("ADMIN")
			.antMatchers("/userSearchLast").hasRole("ADMIN")
			.antMatchers("/userSearchUsername").hasRole("ADMIN")
			.antMatchers("/updateUser").hasRole("ADMIN")
			.antMatchers("/doUpdateUser").hasRole("ADMIN")
			.antMatchers("/deleteUser").hasRole("ADMIN")
			.antMatchers("/products/productAdmin").hasAnyRole("ADMIN", "MANAGER")
			.antMatchers("/products/newProduct").hasAnyRole("ADMIN", "MANAGER")
			.antMatchers("/products/updateProduct").hasAnyRole("ADMIN", "MANAGER")
			.antMatchers("/products/doUpdateProduct").hasAnyRole("ADMIN", "MANAGER")
			.antMatchers("/products/deleteProduct").hasAnyRole("ADMIN", "MANAGER")
			
			
			//settings for API
			.antMatchers(HttpMethod.POST, "/api/**").hasAnyRole("ADMIN", "MANAGER")
			.antMatchers(HttpMethod.PUT, "/api/**").hasAnyRole("ADMIN", "MANAGER")
			.antMatchers(HttpMethod.DELETE, "/api/**").hasRole("ADMIN")
			
			//only logged in uses can access api
			.antMatchers("/api/**").authenticated()
				
			//allow non-logged in users to see the login page and images folder
			.antMatchers("/login", "/img/**").permitAll()
			.and()
			.httpBasic()
			.and()
			.formLogin()

			//no default login
			//.loginPage("/login")
		
			.usernameParameter("username")
			.passwordParameter("password")
			.permitAll()
			//display all orders after login
			.defaultSuccessUrl("/home")
			.and()
			.logout()
			.logoutUrl("/logout")
			.invalidateHttpSession(true)
			.clearAuthentication(true)
			.permitAll()
			.logoutSuccessUrl("/login")
			
			//dont use CSRF
			.and()
			.csrf().ignoringAntMatchers("/api/**");
	}
	
	@Override
	public void configure(AuthenticationManagerBuilder auth) throws Exception
	{
		//use this line to see what encrypted values are of the password 123		
		auth
		.userDetailsService(service)
		.passwordEncoder(passwordEncoder);
	}
}

