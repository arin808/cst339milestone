package com.gcu.business;

import java.util.List;

import com.gcu.model.ProductModel;

public interface ProductsBusinessInterface
{
	//Print test
	public void test();
	
	//Grab CRUD operations
	public ProductModel getByProductId(String id);
	public List<ProductModel> getAllProducts();
	public List<ProductModel> searchProductByName(String searchTerm);
	public List<ProductModel> searchProductByLocation(String searchTerm);
	public String addProduct(ProductModel model);
	public boolean deleteProduct(String id);
	public ProductModel updateProduct(String id, ProductModel updateProduct);
	
	//Lifecycles
	public void init();
	public void destroy();
}
