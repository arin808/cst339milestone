package com.gcu.data;

import java.util.List;

import com.gcu.model.LoginModel;
import com.gcu.model.UserEntity;
import com.gcu.model.UserModel;

public interface UsersDataAccessInterface<T>
{
	public T getById(String id);
	public List<T> getAllUsers();
	public List<UserEntity> searchByUsername(String searchTerm);
	public List<T> searchByFirstName(String searchTerm);
	public List<T> searchByLastName(String searchTerm);
	public String addUser(T model);
	public boolean deleteUser(String id);
	public T updateUser(String id, T updateUser);
}
