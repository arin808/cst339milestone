package com.gcu.data;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

import com.gcu.model.ProductEntity;

@Component
public interface ProductsRepository extends MongoRepository<ProductEntity, String>
{
	@Query("{'vacationName': {'$regex':'?0','$options':'i'}}")
	List<ProductEntity> findByVacationName(String searchTerm);
	@Query("{'location': {'$regex':'?0','$options':'i'}}")
	List<ProductEntity> findByLocation(String searchTerm);
}
