package com.gcu;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gcu.business.ProductsBusinessInterface;
import com.gcu.model.ProductModel;

@RestController
@RequestMapping("/api/products")
public class ProductsRestController
{
	@Autowired
	private ProductsBusinessInterface productsService;
	
	@GetMapping("/")
	public ResponseEntity<?> showAllProducts(Model model)
	{
		try
		{
			List<ProductModel> products = productsService.getAllProducts();
			if(products != null)
			{
				return new ResponseEntity<>(products, HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<?> getOneProduct(@PathVariable(name="id") String id)
	{
		try
		{
			ProductModel product = productsService.getByProductId(id);
			if(product != null)
			{
				return new ResponseEntity<>(product, HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/search/{searchTerm}")
	public ResponseEntity<?> searchProducts(@PathVariable(name="searchTerm") String searchTerm)
	{
		List<ProductModel> results = null;
		try
		{
			results = productsService.searchProductByName(searchTerm);
			if(results != null)
			{
				return new ResponseEntity<>(results, HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/")
	public ResponseEntity<?> addProduct(@RequestBody ProductModel newProduct)
	{
		String results = "";
		try
		{
			results = productsService.addProduct(newProduct);
			if(results != null)
			{
				return new ResponseEntity<>(results, HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteProduct(@PathVariable(name="id") String id)
	{
		boolean result = false;
		try
		{
			result = productsService.deleteProduct(id);
			if(result)
			{
				return new ResponseEntity<>(result, HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PutMapping("/")
	public ResponseEntity<?> updateProduct(@RequestBody ProductModel updateProduct)
	{
		ProductModel result = null;
		try
		{
			result = productsService.updateProduct(updateProduct.getVacationId(), updateProduct);
			if(result != null)
			{
				return new ResponseEntity<>(result, HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
