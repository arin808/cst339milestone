package com.gcu.business;

import java.util.List;

import com.gcu.model.UserModel;

public interface UsersBusinessInterface
{
	//Print test
	public void test();
	
	//Grab CRUD operations
	public UserModel getById(int id);
	public List<UserModel> getAllUsers();
	public List<UserModel> searchUsersFirst(String searchTerm);
	public List<UserModel> searchUsername(String searchTerm);
	public int addUser(UserModel model);
	public boolean deleteUser(int id);
	public UserModel updateUser(int id, UserModel updateUser);
	
	//Lifecycles
	public void init();
	public void destroy();
}
