package com.gcu.data;

import java.util.List;

import com.gcu.model.ProductModel;

public interface ProductsDataAccessInterface<T>
{
	public T getByProductId(String id);
	public List<T> getAllProducts();
	public List<T> searchProductByName(String searchTerm);
	public List<T> searchProductByLocation(String searchTerm);
	public String addProduct(T model);
	public boolean deleteProduct(String id);
	public T updateProduct(String id, T updateProduct);
}
