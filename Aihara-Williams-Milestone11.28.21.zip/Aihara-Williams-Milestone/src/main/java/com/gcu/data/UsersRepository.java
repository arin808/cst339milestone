package com.gcu.data;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Component;

import com.gcu.model.UserEntity;

@Component
public interface UsersRepository extends MongoRepository<UserEntity, String>
{
	List<UserEntity> findByUsername(String searchTerm);
	List<UserEntity> findByFirstName(String searchTerm);
	List<UserEntity> findByLastName(String searchTerm);
}
