package com.gcu.data;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

import com.gcu.model.ProductEntity;

@Component
public interface ProductsRepository extends MongoRepository<ProductEntity, String>
{
	List<ProductEntity> findByVacationName(String searchTerm);
	List<ProductEntity> findByLocation(String searchTerm);
}
