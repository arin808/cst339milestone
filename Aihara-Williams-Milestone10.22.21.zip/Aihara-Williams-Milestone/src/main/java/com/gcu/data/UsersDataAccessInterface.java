package com.gcu.data;

import java.util.List;

import com.gcu.model.UserModel;

public interface UsersDataAccessInterface
{
	public UserModel getById(int id);
	public List<UserModel> getAllUsers();
	public List<UserModel> searchUsersFirst(String searchTerm);
	public List<UserModel> searchUsername(String searchTerm);
	public int addUser(UserModel model);
	public boolean deleteUser(int id);
	public UserModel updateUser(int id, UserModel updateUser);
}
