package com.gcu.data;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.gcu.model.UserModel;

@Repository
public class UsersFakeDAO implements UsersDataAccessInterface
{
	private List<UserModel> users = new ArrayList<UserModel>();
	
	public UsersFakeDAO()
	{
		users.add(new UserModel(0,"Arin", "Aihara", "aaihara@my.gcu.edu", "8082501938", "arin808", "Kaulana")); 
		users.add(new UserModel(0, "Josh", "Williams", "jwilliams425@my.gcu.edu", "1234567890", "kingjosh", "Frontend"));
	}
	
	@Override
	public UserModel getById(int id)
	{
		for(int i = 0; i < users.size(); i++)
		{
			if(users.get(i).getId() == id)
			{
				return users.get(i);
			}
		}
		return null;
	}

	@Override
	public List<UserModel> getAllUsers()
	{
		return users;
	}

	@Override
	public List<UserModel> searchUsersFirst(String searchTerm)
	{
		List<UserModel> results = new ArrayList<UserModel>();
		for(int i = 0; i < users.size(); i++)
		{
			if(users.get(i).getFirstName().equals(searchTerm))
			{
				results.add(users.get(i));
			}
		}
		return results;
	}
	
	@Override
	public List<UserModel> searchUsername(String searchTerm)
	{
		List<UserModel> results = new ArrayList<UserModel>();
		for(int i = 0; i < users.size(); i++)
		{
			if(users.get(i).getUsername().equals(searchTerm))
			{
				results.add(users.get(i));
			}
		}
		return results;
	}
	
	@Override
	public int addUser(UserModel model)
	{
		boolean success = users.add(model);
		if(success)
		{
			System.out.println("New user added");
			return 1;
		}
		return 0;
	}

	@Override
	public boolean deleteUser(int id)
	{
		boolean success = users.remove(users.get(id));
		if(success)
		{
			System.out.println("User deleted");
			return true;
		}
		return false;
	}

	@Override
	public UserModel updateUser(int id, UserModel updateUser)
	{
		for(int i = 0; i < users.size(); i++)
		{
			if(users.get(i).getId() == id)
			{
				users.get(i).setFirstName(updateUser.getFirstName());
				users.get(i).setLastName(updateUser.getLastName());
				users.get(i).setEmail(updateUser.getEmail());
				users.get(i).setPhoneNumber(updateUser.getPhoneNumber());
				users.get(i).setUsername(updateUser.getUsername());
				users.get(i).setPassword(updateUser.getPassword());
				
				System.out.println("Updated user: " + updateUser);
				return users.get(i);
			}
			else
			{
				System.out.println("Couldn't find a matching user to the ID provided.");
				return null;
			}
		}
		
		return null;
	}
	
}
