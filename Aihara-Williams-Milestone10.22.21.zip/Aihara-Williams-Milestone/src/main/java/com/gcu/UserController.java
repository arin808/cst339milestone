package com.gcu;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.gcu.business.SecurityServiceInterface;
import com.gcu.model.LoginModel;
import com.gcu.model.RegistrationModel;

@Controller
@RequestMapping("/")
public class UserController 
{
	@Autowired
	SecurityServiceInterface securityService;
	
	@GetMapping("/home")
	public String homeDisplay()
	{
		return "home";
	}
	
	@GetMapping("/register")
	public String registerDisplay(Model model)
	{
		//Display register screen
		model.addAttribute("title", "Registration");
		model.addAttribute("registrationModel", new RegistrationModel());
		return "register";
	}
	
	@PostMapping("/doRegister")
	public String doRegister(@Valid RegistrationModel registrationModel, BindingResult bindingResult, Model model)
	{
		if(bindingResult.hasErrors())
		{
			model.addAttribute("title", "Registration");
			return "register";
		}
		model.addAttribute("registrationModel", registrationModel);
		 
		return "registerSuccess";
	}
	
	@GetMapping("/login")
	public String loginDisplay(Model model)
	{
		//Display Login form
		model.addAttribute("title", "Login Form");
		model.addAttribute("loginModel", new LoginModel());
		return "login";
	}
	
	@PostMapping("/doLogin")
	public String doLogin(@Valid LoginModel loginModel,  BindingResult bindingResult, Model model)
	{
		//Basic data validation
		if(bindingResult.hasErrors())
		{
			model.addAttribute("title", "Login Form");
			return "login";
		}
		
		if(securityService.isAuthenticated(loginModel))
		{
			securityService.test();
			model.addAttribute("model", loginModel);
			return "loginSuccess";
		}
		else
		{
			//Failed login, redirect back to login page
			return "login";
		}
	}
}
