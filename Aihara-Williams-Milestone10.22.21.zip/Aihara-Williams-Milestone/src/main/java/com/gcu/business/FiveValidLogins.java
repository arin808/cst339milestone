package com.gcu.business;

import java.util.ArrayList;
import java.util.List;

import com.gcu.model.LoginModel;

public class FiveValidLogins implements SecurityServiceInterface
{

	@Override
	public boolean isAuthenticated(LoginModel loginModel)
	{
		//Valid logins
		List<LoginModel> logins = new ArrayList<LoginModel>();
		LoginModel user1 = new LoginModel("Darius", "psw");
		LoginModel user2 = new LoginModel("Zach", "cat");
		LoginModel user3 = new LoginModel("Arin", "koji");
		LoginModel user4 = new LoginModel("Darius", "psw");
		LoginModel user5 = new LoginModel("Kauwila", "zippys");
		
		logins.add(user1);
		logins.add(user2);
		logins.add(user3);
		logins.add(user4);
		logins.add(user5);
		
		boolean success = false;
		for(int i = 0; i < logins.size(); i++)
		{
			if(loginModel.getUsername().equals(logins.get(i).getUsername()) && loginModel.getPassword().equals(logins.get(i).getPassword()))
			{
				success = true;
			}
		}
		if(success)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public void test()
	{
		System.out.println("Security test");
		
	}
}
