package com.gcu.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.gcu.data.UsersDataAccessInterface;
import com.gcu.model.UserModel;

public class UsersBusinessService implements UsersBusinessInterface
{
	@Autowired
	UsersDataAccessInterface usersDAO;
	
	@Override
	public void test()
	{
		System.out.println("Test from UsersBusinessService");
	}

	@Override
	public UserModel getById(int id)
	{
		return usersDAO.getById(id);
	}

	@Override
	public List<UserModel> getAllUsers()
	{
		return usersDAO.getAllUsers();
	}

	@Override
	public List<UserModel> searchUsersFirst(String searchTerm)
	{
		return usersDAO.searchUsersFirst(searchTerm);
	}

	@Override
	public List<UserModel> searchUsername(String searchTerm)
	{
		return usersDAO.searchUsername(searchTerm);
	}

	@Override
	public int addUser(UserModel model)
	{
		return usersDAO.addUser(model);
	}

	@Override
	public boolean deleteUser(int id)
	{
		return usersDAO.deleteUser(id);
	}

	@Override
	public UserModel updateUser(int id, UserModel updateUser)
	{
		return usersDAO.updateUser(id, updateUser);
	}

	@Override
	public void init()
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void destroy()
	{
		// TODO Auto-generated method stub

	}

}
