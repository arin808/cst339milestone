package com.gcu;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gcu.business.UsersBusinessInterface;
import com.gcu.model.UserModel;

@RestController
@RequestMapping("/api/users")
public class UsersRestController
{
	@Autowired
	private UsersBusinessInterface usersService;
	
	@GetMapping("/")
	public ResponseEntity<?> showAllUsers(Model model)
	{
		try
		{
			List<UserModel> users = usersService.getAllUsers();
			if(users != null)
			{
				return new ResponseEntity<>(users, HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<?> getOneUser(@PathVariable(name="id") String id)
	{
		try
		{
			UserModel user = usersService.getById(id);
			if(user != null)
			{
				return new ResponseEntity<>(user, HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/search/{searchTerm}")
	public ResponseEntity<?> searchUsers(@PathVariable(name="searchTerm") String searchTerm)
	{
		List<UserModel> results = null;
		try
		{
			results = usersService.searchByUsername(searchTerm);
			if(results != null)
			{
				return new ResponseEntity<>(results, HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/")
	public ResponseEntity<?> addUser(@RequestBody UserModel newUser)
	{
		String results = "";
		try
		{
			results = usersService.addUser(newUser);
			if(results != null)
			{
				return new ResponseEntity<>(results, HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteUser(@PathVariable(name="id") String id)
	{
		boolean result = false;
		try
		{
			result = usersService.deleteUser(id);
			if(result)
			{
				return new ResponseEntity<>(result, HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PutMapping("/")
	public ResponseEntity<?> updateUser(@RequestBody UserModel updateUser)
	{
		UserModel result = null;
		try
		{
			result = usersService.updateUser(updateUser.getId(), updateUser);
			if(result != null)
			{
				return new ResponseEntity<>(result, HttpStatus.OK);
			}
			else
			{
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		}
		catch(Exception e)
		{
			return new ResponseEntity<>(e, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
