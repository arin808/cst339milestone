package com.gcu.data;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.gcu.model.LoginModel;
import com.gcu.model.UserEntity;
import com.gcu.model.UserModel;

@Service
public class UsersDataServiceForRepository implements UsersDataAccessInterface<UserEntity>
{
	@Autowired
	private UsersRepository usersRepository;

	public UsersDataServiceForRepository(UsersRepository usersRepository)
	{
		this.usersRepository = usersRepository;
	}

	@Override
	public List<UserEntity> getAllUsers()
	{
		List<UserEntity> orders = (List<UserEntity>) usersRepository.findAll();
		return orders;
	}

	@Override
	public UserEntity getById(String id)
	{
		return usersRepository.findById(id).orElse(null);
	}

	@Override
	public List<UserEntity> searchByUsername(String searchTerm)
	{
		List<UserEntity> result = usersRepository.findByUsername(searchTerm);
		return result;
	}
	
	@Override
	public List<UserEntity> searchByFirstName(String searchTerm)
	{
		List<UserEntity> result = usersRepository.findByFirstName(searchTerm);
		return result;
	}
	
	@Override
	public List<UserEntity> searchByLastName(String searchTerm)
	{
		List<UserEntity> result = usersRepository.findByLastName(searchTerm);
		return result;
	}
	
	@Override
	public String addUser(UserEntity model)
	{
		UserEntity result = usersRepository.save(model);
		if (result == null)
		{
			return null;
		}
		return result.getId();
	}

	@Override
	public boolean deleteUser(String id)
	{
		usersRepository.deleteById(id);
		return true;
	}

	@Override
	public UserEntity updateUser(String id, UserEntity updateOrder)
	{
		UserEntity result = usersRepository.save(updateOrder);
		return result;
	}
}