package com.gcu.data;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Component;

import com.gcu.model.UserEntity;

@Component
public interface UsersRepository extends MongoRepository<UserEntity, String>
{
	@Query("{'username': {'$regex':'?0','$options':'i'}}")
	List<UserEntity> findByUsername(String searchTerm);
	@Query("{'firstName': {'$regex':'?0','$options':'i'}}")
	List<UserEntity> findByFirstName(String searchTerm);
	@Query("{'lastName': {'$regex':'?0','$options':'i'}}")
	List<UserEntity> findByLastName(String searchTerm);
}
