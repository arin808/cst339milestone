package com.gcu.model;

public class SearchModel
{
	private String searchTerm;

	public String getSearchTerm()
	{
		return searchTerm;
	}
	public void setSearchTerm(String searchTerm) 
	{
		this.searchTerm = searchTerm;
	}
}